import * as ts from 'typescript';
import { type IExcerptToken, type IExcerptTokenRange } from '@microsoft/api-extractor-model';
import type { DeclarationReferenceGenerator } from './DeclarationReferenceGenerator';
import type { AstDeclaration } from '../analyzer/AstDeclaration';
/**
 * Used to provide ExcerptBuilder with a list of nodes whose token range we want to capture.
 */
export interface IExcerptBuilderNodeTransform {
    /**
     * The node to process
     */
    node: ts.Node;
    /**
     * A token range whose startIndex/endIndex will be overwritten with the indexes for the
     * tokens corresponding to IExcerptBuilderNodeTransform.node
     */
    captureTokenRange?: IExcerptTokenRange;
    /**
     * Text that will replace the text of the given node during emit.
     */
    replacementText?: string;
}
export declare class ExcerptBuilder {
    /**
     * Appends a blank line to the `excerptTokens` list.
     * @param excerptTokens - The target token list to append to
     */
    static addBlankLine(excerptTokens: IExcerptToken[]): void;
    /**
     * Appends the signature for the specified `AstDeclaration` to the `excerptTokens` list.
     * @param excerptTokens - The target token list to append to
     * @param nodeTransforms - A list of child nodes whose token ranges we want to capture
     */
    static addDeclaration(excerptTokens: IExcerptToken[], astDeclaration: AstDeclaration, nodeTransforms: IExcerptBuilderNodeTransform[], referenceGenerator: DeclarationReferenceGenerator): void;
    static createEmptyTokenRange(): IExcerptTokenRange;
}
//# sourceMappingURL=ExcerptBuilder.d.ts.map