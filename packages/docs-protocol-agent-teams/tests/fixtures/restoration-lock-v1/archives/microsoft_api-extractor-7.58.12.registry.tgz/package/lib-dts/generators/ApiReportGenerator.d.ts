import { Collector } from '../collector/Collector';
import type { ApiReportVariant } from '../api/IConfigFile';
export declare class ApiReportGenerator {
    /**
     * Compares the contents of two API files that were created using ApiFileGenerator,
     * and returns true if they are equivalent.  Note that these files are not normally edited
     * by a human; the "equivalence" comparison here is intended to ignore spurious changes that
     * might be introduced by a tool, e.g. Git newline normalization or an editor that strips
     * whitespace when saving.
     */
    static areEquivalentApiFileContents(actualFileContent: string, expectedFileContent: string): boolean;
    /**
     * Generates and returns the API report contents as a string.
     *
     * @param reportVariant - The release level with which the report is associated.
     * Can also be viewed as the minimal release level of items that should be included in the report.
     */
    static generateReviewFileContent(collector: Collector, reportVariant: ApiReportVariant): string;
}
//# sourceMappingURL=ApiReportGenerator.d.ts.map