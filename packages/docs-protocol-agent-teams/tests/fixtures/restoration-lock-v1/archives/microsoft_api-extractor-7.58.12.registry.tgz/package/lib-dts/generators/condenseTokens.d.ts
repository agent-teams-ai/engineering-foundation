import { type IExcerptToken, type IExcerptTokenRange } from '@microsoft/api-extractor-model';
/**
 * Condenses the provided excerpt tokens by merging tokens where possible. Updates the provided token ranges to
 * remain accurate after token merging.
 *
 * @remarks
 * For example, suppose we have excerpt tokens ["A", "B", "C"] and a token range [0, 2]. If the excerpt tokens
 * are condensed to ["AB", "C"], then the token range would be updated to [0, 1]. Note that merges are only
 * performed if they are compatible with the provided token ranges. In the example above, if our token range was
 * originally [0, 1], we would not be able to merge tokens "A" and "B".
 */
export declare function condenseTokens(excerptTokens: IExcerptToken[], tokenRanges: IExcerptTokenRange[]): void;
//# sourceMappingURL=condenseTokens.d.ts.map