import type { Collector } from '../collector/Collector';
export declare class ValidationEnhancer {
    static analyze(collector: Collector): void;
}
//# sourceMappingURL=ValidationEnhancer.d.ts.map